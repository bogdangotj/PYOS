# Способ 1 — через edit
edit calc.x4
# вставить содержимое, :wq
app install calc.x4

edit calcplus.x4
# вставить содержимое, :wq
app install calcplus.x4

# Способ 2 — если файлы уже на реальном диске
# просто скопируй файлы в PyOS_Files/hostname/C/home/user/
# потом:
app install calc.x4
app install calcplus.x4

# Запуск
calc
calcplus